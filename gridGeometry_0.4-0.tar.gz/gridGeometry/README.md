# gridgeometry
A geometry engine interface for 'grid' grobs
